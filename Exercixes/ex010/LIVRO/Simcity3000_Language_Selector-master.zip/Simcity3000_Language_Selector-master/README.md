	Project Website: https://tetration.github.io/Simcity3000_Modding_Revival/index.html

	Developer: Tetration

	Github address: https://github.com/tetration

	Github repository: https://github.com/tetration/Simcity3000-HD-patch

	contact: Tetration@outlook.com

Simcty 3000 Language Selector:

Simcity 3000/ Simcity 3000 Unlimited Language Selector (Windows and Linux)


Simcity 3000 Unlimited/ Simcity 3000 Language patch:

				By using this python script you will be able to change the language of your game to one
				one of the following:

				<b>Portuguese Brazilian</b>
				<b>Polish</b>
				<b>Russian</b>
<b>Linux users:</b> You will be able to easily change the language of the game as many times as 
you want without having to reinstall it
				
Python 2.7 script tested under Windows 10 64 bit and DeepinOS 15.5 64bit using Simcity 3000 Unlimited GOG Edition(Windows) 
and Simcity 3000 Unlimited Loki Games Edition(Linux) for our testing purposes.


Instructions to patch the game:

1: Make sure to install Simcity 3000/3000 Unlimited with English as the default language

2: Make sure python 2.7 is installed in your current Windows system

2.1: You can download it at (https://www.python.org/downloads/) to your current OS  in order to make this script work

3: Dowload my script(https://github.com/tetration/Simcity3000_Language_Selector/archive/master.zip) you havent done so.


4:Place this python script in the same Res folder of Simcity 3000.
	4.1:Windows version: Folder can be located in something like C\:GOG\Simcity 3000 Unlimited\Apps\Res
	4.12:Linux version: Folder location can be located in something like home\usr\SimCity3000 Unlimited\Res</p>


5: Run the script(SCU3_Language_selector.py) by left-clicking twice on it

6: Enjoy running the game in your native tongue!
Observations:
	-The Script will make a backup file of the original executable(SC3U1.exe) of the game before making any changes in it


FAQ:

Why your script wont run and say that its not in the right directory? I placed it inside my main Simcity 3000 Folder!!!


You placed in the wrong directory you are supposed to place it inside the "Res" directory which is located in the Simcity 3000 Folder

The script only works in the Linux and Windows versions of this game!